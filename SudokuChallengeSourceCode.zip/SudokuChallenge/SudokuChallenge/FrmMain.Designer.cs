﻿namespace SudokuChallenge
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.btnExit = new System.Windows.Forms.Button();
            this.rchTxtBx03 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx04 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx05 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx06 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx07 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx08 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx13 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx14 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx15 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx16 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx17 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx18 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx23 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx24 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx25 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx26 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx27 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx28 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx30 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx31 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx32 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx33 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx34 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx35 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx36 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx37 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx38 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx40 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx41 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx42 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx43 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx44 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx45 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx46 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx47 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx48 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx50 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx51 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx52 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx53 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx54 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx55 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx56 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx57 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx58 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx60 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx61 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx62 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx63 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx64 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx65 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx66 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx67 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx68 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx70 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx71 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx72 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx73 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx74 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx75 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx76 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx77 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx78 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx80 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx81 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx82 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx83 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx84 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx85 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx86 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx87 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx88 = new System.Windows.Forms.RichTextBox();
            this.groupBxPuzzle = new System.Windows.Forms.GroupBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rchTxtBx22 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx21 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx20 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx12 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx11 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx10 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx02 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx01 = new System.Windows.Forms.RichTextBox();
            this.rchTxtBx00 = new System.Windows.Forms.RichTextBox();
            this.btnSolve = new System.Windows.Forms.Button();
            this.cmbBxPuzzles = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBxPuzzle.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.BackColor = System.Drawing.Color.Silver;
            this.btnExit.ForeColor = System.Drawing.Color.Red;
            this.btnExit.Location = new System.Drawing.Point(111, 406);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(77, 23);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // rchTxtBx03
            // 
            this.rchTxtBx03.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx03.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx03.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx03.Location = new System.Drawing.Point(3, 3);
            this.rchTxtBx03.Name = "rchTxtBx03";
            this.rchTxtBx03.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx03.TabIndex = 3;
            this.rchTxtBx03.Text = "";
            // 
            // rchTxtBx04
            // 
            this.rchTxtBx04.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx04.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx04.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx04.Location = new System.Drawing.Point(31, 3);
            this.rchTxtBx04.Name = "rchTxtBx04";
            this.rchTxtBx04.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx04.TabIndex = 4;
            this.rchTxtBx04.Text = "";
            // 
            // rchTxtBx05
            // 
            this.rchTxtBx05.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx05.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx05.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx05.Location = new System.Drawing.Point(59, 3);
            this.rchTxtBx05.Name = "rchTxtBx05";
            this.rchTxtBx05.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx05.TabIndex = 5;
            this.rchTxtBx05.Text = "";
            // 
            // rchTxtBx06
            // 
            this.rchTxtBx06.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx06.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx06.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx06.Location = new System.Drawing.Point(2, 3);
            this.rchTxtBx06.Name = "rchTxtBx06";
            this.rchTxtBx06.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx06.TabIndex = 6;
            this.rchTxtBx06.Text = "";
            // 
            // rchTxtBx07
            // 
            this.rchTxtBx07.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx07.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx07.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx07.Location = new System.Drawing.Point(30, 3);
            this.rchTxtBx07.Name = "rchTxtBx07";
            this.rchTxtBx07.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx07.TabIndex = 7;
            this.rchTxtBx07.Text = "";
            // 
            // rchTxtBx08
            // 
            this.rchTxtBx08.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx08.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx08.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx08.Location = new System.Drawing.Point(59, 3);
            this.rchTxtBx08.Name = "rchTxtBx08";
            this.rchTxtBx08.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx08.TabIndex = 8;
            this.rchTxtBx08.Text = "";
            // 
            // rchTxtBx13
            // 
            this.rchTxtBx13.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx13.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx13.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx13.Location = new System.Drawing.Point(3, 31);
            this.rchTxtBx13.Name = "rchTxtBx13";
            this.rchTxtBx13.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx13.TabIndex = 12;
            this.rchTxtBx13.Text = "";
            // 
            // rchTxtBx14
            // 
            this.rchTxtBx14.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx14.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx14.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx14.Location = new System.Drawing.Point(31, 31);
            this.rchTxtBx14.Name = "rchTxtBx14";
            this.rchTxtBx14.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx14.TabIndex = 13;
            this.rchTxtBx14.Text = "";
            // 
            // rchTxtBx15
            // 
            this.rchTxtBx15.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx15.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx15.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx15.Location = new System.Drawing.Point(59, 31);
            this.rchTxtBx15.Name = "rchTxtBx15";
            this.rchTxtBx15.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx15.TabIndex = 14;
            this.rchTxtBx15.Text = "";
            // 
            // rchTxtBx16
            // 
            this.rchTxtBx16.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx16.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx16.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx16.Location = new System.Drawing.Point(2, 31);
            this.rchTxtBx16.Name = "rchTxtBx16";
            this.rchTxtBx16.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx16.TabIndex = 15;
            this.rchTxtBx16.Text = "";
            // 
            // rchTxtBx17
            // 
            this.rchTxtBx17.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx17.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx17.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx17.Location = new System.Drawing.Point(30, 31);
            this.rchTxtBx17.Name = "rchTxtBx17";
            this.rchTxtBx17.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx17.TabIndex = 16;
            this.rchTxtBx17.Text = "";
            // 
            // rchTxtBx18
            // 
            this.rchTxtBx18.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx18.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx18.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx18.Location = new System.Drawing.Point(59, 31);
            this.rchTxtBx18.Name = "rchTxtBx18";
            this.rchTxtBx18.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx18.TabIndex = 17;
            this.rchTxtBx18.Text = "";
            // 
            // rchTxtBx23
            // 
            this.rchTxtBx23.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx23.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx23.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx23.Location = new System.Drawing.Point(3, 59);
            this.rchTxtBx23.Name = "rchTxtBx23";
            this.rchTxtBx23.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx23.TabIndex = 21;
            this.rchTxtBx23.Text = "";
            // 
            // rchTxtBx24
            // 
            this.rchTxtBx24.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx24.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx24.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx24.Location = new System.Drawing.Point(31, 59);
            this.rchTxtBx24.Name = "rchTxtBx24";
            this.rchTxtBx24.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx24.TabIndex = 22;
            this.rchTxtBx24.Text = "";
            // 
            // rchTxtBx25
            // 
            this.rchTxtBx25.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx25.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx25.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx25.Location = new System.Drawing.Point(59, 59);
            this.rchTxtBx25.Name = "rchTxtBx25";
            this.rchTxtBx25.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx25.TabIndex = 23;
            this.rchTxtBx25.Text = "";
            // 
            // rchTxtBx26
            // 
            this.rchTxtBx26.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx26.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx26.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx26.Location = new System.Drawing.Point(2, 59);
            this.rchTxtBx26.Name = "rchTxtBx26";
            this.rchTxtBx26.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx26.TabIndex = 24;
            this.rchTxtBx26.Text = "";
            // 
            // rchTxtBx27
            // 
            this.rchTxtBx27.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx27.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx27.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx27.Location = new System.Drawing.Point(30, 59);
            this.rchTxtBx27.Name = "rchTxtBx27";
            this.rchTxtBx27.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx27.TabIndex = 25;
            this.rchTxtBx27.Text = "";
            // 
            // rchTxtBx28
            // 
            this.rchTxtBx28.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx28.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx28.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx28.Location = new System.Drawing.Point(59, 59);
            this.rchTxtBx28.Name = "rchTxtBx28";
            this.rchTxtBx28.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx28.TabIndex = 26;
            this.rchTxtBx28.Text = "";
            // 
            // rchTxtBx30
            // 
            this.rchTxtBx30.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx30.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx30.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx30.Location = new System.Drawing.Point(3, 4);
            this.rchTxtBx30.Name = "rchTxtBx30";
            this.rchTxtBx30.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx30.TabIndex = 27;
            this.rchTxtBx30.Text = "";
            // 
            // rchTxtBx31
            // 
            this.rchTxtBx31.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx31.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx31.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx31.Location = new System.Drawing.Point(31, 4);
            this.rchTxtBx31.Name = "rchTxtBx31";
            this.rchTxtBx31.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx31.TabIndex = 28;
            this.rchTxtBx31.Text = "";
            // 
            // rchTxtBx32
            // 
            this.rchTxtBx32.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx32.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx32.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx32.Location = new System.Drawing.Point(59, 4);
            this.rchTxtBx32.Name = "rchTxtBx32";
            this.rchTxtBx32.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx32.TabIndex = 29;
            this.rchTxtBx32.Text = "";
            // 
            // rchTxtBx33
            // 
            this.rchTxtBx33.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx33.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx33.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx33.Location = new System.Drawing.Point(3, 3);
            this.rchTxtBx33.Name = "rchTxtBx33";
            this.rchTxtBx33.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx33.TabIndex = 30;
            this.rchTxtBx33.Text = "";
            // 
            // rchTxtBx34
            // 
            this.rchTxtBx34.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx34.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx34.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx34.Location = new System.Drawing.Point(31, 3);
            this.rchTxtBx34.Name = "rchTxtBx34";
            this.rchTxtBx34.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx34.TabIndex = 31;
            this.rchTxtBx34.Text = "";
            // 
            // rchTxtBx35
            // 
            this.rchTxtBx35.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx35.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx35.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx35.Location = new System.Drawing.Point(59, 3);
            this.rchTxtBx35.Name = "rchTxtBx35";
            this.rchTxtBx35.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx35.TabIndex = 32;
            this.rchTxtBx35.Text = "";
            // 
            // rchTxtBx36
            // 
            this.rchTxtBx36.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx36.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx36.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx36.Location = new System.Drawing.Point(3, 3);
            this.rchTxtBx36.Name = "rchTxtBx36";
            this.rchTxtBx36.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx36.TabIndex = 33;
            this.rchTxtBx36.Text = "";
            // 
            // rchTxtBx37
            // 
            this.rchTxtBx37.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx37.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx37.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx37.Location = new System.Drawing.Point(31, 3);
            this.rchTxtBx37.Name = "rchTxtBx37";
            this.rchTxtBx37.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx37.TabIndex = 34;
            this.rchTxtBx37.Text = "";
            // 
            // rchTxtBx38
            // 
            this.rchTxtBx38.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx38.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx38.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx38.Location = new System.Drawing.Point(60, 3);
            this.rchTxtBx38.Name = "rchTxtBx38";
            this.rchTxtBx38.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx38.TabIndex = 35;
            this.rchTxtBx38.Text = "";
            // 
            // rchTxtBx40
            // 
            this.rchTxtBx40.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx40.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx40.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx40.Location = new System.Drawing.Point(3, 32);
            this.rchTxtBx40.Name = "rchTxtBx40";
            this.rchTxtBx40.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx40.TabIndex = 36;
            this.rchTxtBx40.Text = "";
            // 
            // rchTxtBx41
            // 
            this.rchTxtBx41.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx41.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx41.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx41.Location = new System.Drawing.Point(31, 32);
            this.rchTxtBx41.Name = "rchTxtBx41";
            this.rchTxtBx41.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx41.TabIndex = 37;
            this.rchTxtBx41.Text = "";
            // 
            // rchTxtBx42
            // 
            this.rchTxtBx42.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx42.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx42.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx42.Location = new System.Drawing.Point(59, 32);
            this.rchTxtBx42.Name = "rchTxtBx42";
            this.rchTxtBx42.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx42.TabIndex = 38;
            this.rchTxtBx42.Text = "";
            // 
            // rchTxtBx43
            // 
            this.rchTxtBx43.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx43.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx43.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx43.Location = new System.Drawing.Point(3, 31);
            this.rchTxtBx43.Name = "rchTxtBx43";
            this.rchTxtBx43.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx43.TabIndex = 39;
            this.rchTxtBx43.Text = "";
            // 
            // rchTxtBx44
            // 
            this.rchTxtBx44.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx44.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx44.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx44.Location = new System.Drawing.Point(31, 31);
            this.rchTxtBx44.Name = "rchTxtBx44";
            this.rchTxtBx44.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx44.TabIndex = 40;
            this.rchTxtBx44.Text = "";
            // 
            // rchTxtBx45
            // 
            this.rchTxtBx45.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx45.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx45.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx45.Location = new System.Drawing.Point(59, 31);
            this.rchTxtBx45.Name = "rchTxtBx45";
            this.rchTxtBx45.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx45.TabIndex = 41;
            this.rchTxtBx45.Text = "";
            // 
            // rchTxtBx46
            // 
            this.rchTxtBx46.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx46.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx46.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx46.Location = new System.Drawing.Point(3, 31);
            this.rchTxtBx46.Name = "rchTxtBx46";
            this.rchTxtBx46.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx46.TabIndex = 42;
            this.rchTxtBx46.Text = "";
            // 
            // rchTxtBx47
            // 
            this.rchTxtBx47.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx47.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx47.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx47.Location = new System.Drawing.Point(31, 31);
            this.rchTxtBx47.Name = "rchTxtBx47";
            this.rchTxtBx47.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx47.TabIndex = 43;
            this.rchTxtBx47.Text = "";
            // 
            // rchTxtBx48
            // 
            this.rchTxtBx48.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx48.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx48.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx48.Location = new System.Drawing.Point(60, 31);
            this.rchTxtBx48.Name = "rchTxtBx48";
            this.rchTxtBx48.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx48.TabIndex = 44;
            this.rchTxtBx48.Text = "";
            // 
            // rchTxtBx50
            // 
            this.rchTxtBx50.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx50.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx50.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx50.Location = new System.Drawing.Point(3, 60);
            this.rchTxtBx50.Name = "rchTxtBx50";
            this.rchTxtBx50.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx50.TabIndex = 45;
            this.rchTxtBx50.Text = "";
            // 
            // rchTxtBx51
            // 
            this.rchTxtBx51.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx51.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx51.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx51.Location = new System.Drawing.Point(31, 60);
            this.rchTxtBx51.Name = "rchTxtBx51";
            this.rchTxtBx51.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx51.TabIndex = 46;
            this.rchTxtBx51.Text = "";
            // 
            // rchTxtBx52
            // 
            this.rchTxtBx52.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx52.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx52.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx52.Location = new System.Drawing.Point(59, 60);
            this.rchTxtBx52.Name = "rchTxtBx52";
            this.rchTxtBx52.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx52.TabIndex = 47;
            this.rchTxtBx52.Text = "";
            // 
            // rchTxtBx53
            // 
            this.rchTxtBx53.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx53.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx53.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx53.Location = new System.Drawing.Point(3, 59);
            this.rchTxtBx53.Name = "rchTxtBx53";
            this.rchTxtBx53.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx53.TabIndex = 48;
            this.rchTxtBx53.Text = "";
            // 
            // rchTxtBx54
            // 
            this.rchTxtBx54.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx54.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx54.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx54.Location = new System.Drawing.Point(31, 59);
            this.rchTxtBx54.Name = "rchTxtBx54";
            this.rchTxtBx54.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx54.TabIndex = 49;
            this.rchTxtBx54.Text = "";
            // 
            // rchTxtBx55
            // 
            this.rchTxtBx55.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx55.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx55.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx55.Location = new System.Drawing.Point(59, 59);
            this.rchTxtBx55.Name = "rchTxtBx55";
            this.rchTxtBx55.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx55.TabIndex = 50;
            this.rchTxtBx55.Text = "";
            // 
            // rchTxtBx56
            // 
            this.rchTxtBx56.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx56.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx56.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx56.Location = new System.Drawing.Point(3, 59);
            this.rchTxtBx56.Name = "rchTxtBx56";
            this.rchTxtBx56.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx56.TabIndex = 51;
            this.rchTxtBx56.Text = "";
            // 
            // rchTxtBx57
            // 
            this.rchTxtBx57.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx57.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx57.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx57.Location = new System.Drawing.Point(31, 59);
            this.rchTxtBx57.Name = "rchTxtBx57";
            this.rchTxtBx57.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx57.TabIndex = 52;
            this.rchTxtBx57.Text = "";
            // 
            // rchTxtBx58
            // 
            this.rchTxtBx58.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx58.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx58.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx58.Location = new System.Drawing.Point(60, 59);
            this.rchTxtBx58.Name = "rchTxtBx58";
            this.rchTxtBx58.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx58.TabIndex = 53;
            this.rchTxtBx58.Text = "";
            // 
            // rchTxtBx60
            // 
            this.rchTxtBx60.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx60.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx60.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx60.Location = new System.Drawing.Point(3, 3);
            this.rchTxtBx60.Name = "rchTxtBx60";
            this.rchTxtBx60.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx60.TabIndex = 54;
            this.rchTxtBx60.Text = "";
            // 
            // rchTxtBx61
            // 
            this.rchTxtBx61.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx61.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx61.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx61.Location = new System.Drawing.Point(31, 3);
            this.rchTxtBx61.Name = "rchTxtBx61";
            this.rchTxtBx61.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx61.TabIndex = 55;
            this.rchTxtBx61.Text = "";
            // 
            // rchTxtBx62
            // 
            this.rchTxtBx62.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx62.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx62.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx62.Location = new System.Drawing.Point(59, 3);
            this.rchTxtBx62.Name = "rchTxtBx62";
            this.rchTxtBx62.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx62.TabIndex = 56;
            this.rchTxtBx62.Text = "";
            // 
            // rchTxtBx63
            // 
            this.rchTxtBx63.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx63.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx63.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx63.Location = new System.Drawing.Point(3, 3);
            this.rchTxtBx63.Name = "rchTxtBx63";
            this.rchTxtBx63.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx63.TabIndex = 57;
            this.rchTxtBx63.Text = "";
            // 
            // rchTxtBx64
            // 
            this.rchTxtBx64.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx64.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx64.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx64.Location = new System.Drawing.Point(31, 3);
            this.rchTxtBx64.Name = "rchTxtBx64";
            this.rchTxtBx64.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx64.TabIndex = 58;
            this.rchTxtBx64.Text = "";
            // 
            // rchTxtBx65
            // 
            this.rchTxtBx65.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx65.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx65.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx65.Location = new System.Drawing.Point(59, 3);
            this.rchTxtBx65.Name = "rchTxtBx65";
            this.rchTxtBx65.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx65.TabIndex = 59;
            this.rchTxtBx65.Text = "";
            // 
            // rchTxtBx66
            // 
            this.rchTxtBx66.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx66.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx66.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx66.Location = new System.Drawing.Point(3, 3);
            this.rchTxtBx66.Name = "rchTxtBx66";
            this.rchTxtBx66.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx66.TabIndex = 60;
            this.rchTxtBx66.Text = "";
            // 
            // rchTxtBx67
            // 
            this.rchTxtBx67.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx67.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx67.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx67.Location = new System.Drawing.Point(31, 3);
            this.rchTxtBx67.Name = "rchTxtBx67";
            this.rchTxtBx67.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx67.TabIndex = 61;
            this.rchTxtBx67.Text = "";
            // 
            // rchTxtBx68
            // 
            this.rchTxtBx68.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx68.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx68.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx68.Location = new System.Drawing.Point(60, 3);
            this.rchTxtBx68.Name = "rchTxtBx68";
            this.rchTxtBx68.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx68.TabIndex = 62;
            this.rchTxtBx68.Text = "";
            // 
            // rchTxtBx70
            // 
            this.rchTxtBx70.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx70.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx70.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx70.Location = new System.Drawing.Point(3, 31);
            this.rchTxtBx70.Name = "rchTxtBx70";
            this.rchTxtBx70.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx70.TabIndex = 63;
            this.rchTxtBx70.Text = "";
            // 
            // rchTxtBx71
            // 
            this.rchTxtBx71.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx71.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx71.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx71.Location = new System.Drawing.Point(31, 31);
            this.rchTxtBx71.Name = "rchTxtBx71";
            this.rchTxtBx71.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx71.TabIndex = 64;
            this.rchTxtBx71.Text = "";
            // 
            // rchTxtBx72
            // 
            this.rchTxtBx72.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx72.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx72.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx72.Location = new System.Drawing.Point(59, 31);
            this.rchTxtBx72.Name = "rchTxtBx72";
            this.rchTxtBx72.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx72.TabIndex = 65;
            this.rchTxtBx72.Text = "";
            // 
            // rchTxtBx73
            // 
            this.rchTxtBx73.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx73.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx73.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx73.Location = new System.Drawing.Point(3, 31);
            this.rchTxtBx73.Name = "rchTxtBx73";
            this.rchTxtBx73.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx73.TabIndex = 66;
            this.rchTxtBx73.Text = "";
            // 
            // rchTxtBx74
            // 
            this.rchTxtBx74.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx74.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx74.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx74.Location = new System.Drawing.Point(31, 31);
            this.rchTxtBx74.Name = "rchTxtBx74";
            this.rchTxtBx74.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx74.TabIndex = 67;
            this.rchTxtBx74.Text = "";
            // 
            // rchTxtBx75
            // 
            this.rchTxtBx75.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx75.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx75.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx75.Location = new System.Drawing.Point(59, 31);
            this.rchTxtBx75.Name = "rchTxtBx75";
            this.rchTxtBx75.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx75.TabIndex = 68;
            this.rchTxtBx75.Text = "";
            // 
            // rchTxtBx76
            // 
            this.rchTxtBx76.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx76.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx76.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx76.Location = new System.Drawing.Point(3, 31);
            this.rchTxtBx76.Name = "rchTxtBx76";
            this.rchTxtBx76.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx76.TabIndex = 69;
            this.rchTxtBx76.Text = "";
            // 
            // rchTxtBx77
            // 
            this.rchTxtBx77.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx77.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx77.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx77.Location = new System.Drawing.Point(31, 31);
            this.rchTxtBx77.Name = "rchTxtBx77";
            this.rchTxtBx77.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx77.TabIndex = 70;
            this.rchTxtBx77.Text = "";
            // 
            // rchTxtBx78
            // 
            this.rchTxtBx78.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx78.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx78.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx78.Location = new System.Drawing.Point(60, 31);
            this.rchTxtBx78.Name = "rchTxtBx78";
            this.rchTxtBx78.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx78.TabIndex = 71;
            this.rchTxtBx78.Text = "";
            // 
            // rchTxtBx80
            // 
            this.rchTxtBx80.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx80.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx80.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx80.Location = new System.Drawing.Point(3, 59);
            this.rchTxtBx80.Name = "rchTxtBx80";
            this.rchTxtBx80.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx80.TabIndex = 72;
            this.rchTxtBx80.Text = "";
            // 
            // rchTxtBx81
            // 
            this.rchTxtBx81.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx81.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx81.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx81.Location = new System.Drawing.Point(31, 59);
            this.rchTxtBx81.Name = "rchTxtBx81";
            this.rchTxtBx81.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx81.TabIndex = 73;
            this.rchTxtBx81.Text = "";
            // 
            // rchTxtBx82
            // 
            this.rchTxtBx82.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx82.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx82.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx82.Location = new System.Drawing.Point(59, 59);
            this.rchTxtBx82.Name = "rchTxtBx82";
            this.rchTxtBx82.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx82.TabIndex = 74;
            this.rchTxtBx82.Text = "";
            // 
            // rchTxtBx83
            // 
            this.rchTxtBx83.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx83.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx83.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx83.Location = new System.Drawing.Point(3, 59);
            this.rchTxtBx83.Name = "rchTxtBx83";
            this.rchTxtBx83.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx83.TabIndex = 75;
            this.rchTxtBx83.Text = "";
            // 
            // rchTxtBx84
            // 
            this.rchTxtBx84.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx84.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx84.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx84.Location = new System.Drawing.Point(31, 59);
            this.rchTxtBx84.Name = "rchTxtBx84";
            this.rchTxtBx84.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx84.TabIndex = 76;
            this.rchTxtBx84.Text = "";
            // 
            // rchTxtBx85
            // 
            this.rchTxtBx85.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx85.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx85.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx85.Location = new System.Drawing.Point(59, 59);
            this.rchTxtBx85.Name = "rchTxtBx85";
            this.rchTxtBx85.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx85.TabIndex = 77;
            this.rchTxtBx85.Text = "";
            // 
            // rchTxtBx86
            // 
            this.rchTxtBx86.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx86.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx86.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx86.Location = new System.Drawing.Point(3, 59);
            this.rchTxtBx86.Name = "rchTxtBx86";
            this.rchTxtBx86.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx86.TabIndex = 78;
            this.rchTxtBx86.Text = "";
            // 
            // rchTxtBx87
            // 
            this.rchTxtBx87.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx87.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx87.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx87.Location = new System.Drawing.Point(31, 59);
            this.rchTxtBx87.Name = "rchTxtBx87";
            this.rchTxtBx87.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx87.TabIndex = 79;
            this.rchTxtBx87.Text = "";
            // 
            // rchTxtBx88
            // 
            this.rchTxtBx88.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx88.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx88.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx88.Location = new System.Drawing.Point(60, 59);
            this.rchTxtBx88.Name = "rchTxtBx88";
            this.rchTxtBx88.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx88.TabIndex = 80;
            this.rchTxtBx88.Text = "";
            // 
            // groupBxPuzzle
            // 
            this.groupBxPuzzle.BackColor = System.Drawing.Color.LightSteelBlue;
            this.groupBxPuzzle.Controls.Add(this.panel9);
            this.groupBxPuzzle.Controls.Add(this.panel8);
            this.groupBxPuzzle.Controls.Add(this.panel7);
            this.groupBxPuzzle.Controls.Add(this.panel6);
            this.groupBxPuzzle.Controls.Add(this.panel5);
            this.groupBxPuzzle.Controls.Add(this.panel4);
            this.groupBxPuzzle.Controls.Add(this.panel2);
            this.groupBxPuzzle.Controls.Add(this.panel3);
            this.groupBxPuzzle.Controls.Add(this.panel1);
            this.groupBxPuzzle.Location = new System.Drawing.Point(11, 12);
            this.groupBxPuzzle.Name = "groupBxPuzzle";
            this.groupBxPuzzle.Size = new System.Drawing.Size(276, 289);
            this.groupBxPuzzle.TabIndex = 3;
            this.groupBxPuzzle.TabStop = false;
            this.groupBxPuzzle.Text = "Puzzle";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel9.Controls.Add(this.rchTxtBx88);
            this.panel9.Controls.Add(this.rchTxtBx66);
            this.panel9.Controls.Add(this.rchTxtBx67);
            this.panel9.Controls.Add(this.rchTxtBx68);
            this.panel9.Controls.Add(this.rchTxtBx76);
            this.panel9.Controls.Add(this.rchTxtBx77);
            this.panel9.Controls.Add(this.rchTxtBx78);
            this.panel9.Controls.Add(this.rchTxtBx86);
            this.panel9.Controls.Add(this.rchTxtBx87);
            this.panel9.Location = new System.Drawing.Point(182, 193);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(88, 87);
            this.panel9.TabIndex = 12;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel8.Controls.Add(this.rchTxtBx63);
            this.panel8.Controls.Add(this.rchTxtBx64);
            this.panel8.Controls.Add(this.rchTxtBx65);
            this.panel8.Controls.Add(this.rchTxtBx73);
            this.panel8.Controls.Add(this.rchTxtBx74);
            this.panel8.Controls.Add(this.rchTxtBx75);
            this.panel8.Controls.Add(this.rchTxtBx83);
            this.panel8.Controls.Add(this.rchTxtBx84);
            this.panel8.Controls.Add(this.rchTxtBx85);
            this.panel8.Location = new System.Drawing.Point(94, 193);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(87, 87);
            this.panel8.TabIndex = 11;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel7.Controls.Add(this.rchTxtBx58);
            this.panel7.Controls.Add(this.rchTxtBx36);
            this.panel7.Controls.Add(this.rchTxtBx37);
            this.panel7.Controls.Add(this.rchTxtBx38);
            this.panel7.Controls.Add(this.rchTxtBx46);
            this.panel7.Controls.Add(this.rchTxtBx47);
            this.panel7.Controls.Add(this.rchTxtBx48);
            this.panel7.Controls.Add(this.rchTxtBx56);
            this.panel7.Controls.Add(this.rchTxtBx57);
            this.panel7.Location = new System.Drawing.Point(182, 106);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(88, 87);
            this.panel7.TabIndex = 10;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel6.Controls.Add(this.rchTxtBx33);
            this.panel6.Controls.Add(this.rchTxtBx34);
            this.panel6.Controls.Add(this.rchTxtBx35);
            this.panel6.Controls.Add(this.rchTxtBx43);
            this.panel6.Controls.Add(this.rchTxtBx44);
            this.panel6.Controls.Add(this.rchTxtBx45);
            this.panel6.Controls.Add(this.rchTxtBx53);
            this.panel6.Controls.Add(this.rchTxtBx54);
            this.panel6.Controls.Add(this.rchTxtBx55);
            this.panel6.Location = new System.Drawing.Point(94, 106);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(87, 87);
            this.panel6.TabIndex = 9;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel5.Controls.Add(this.rchTxtBx06);
            this.panel5.Controls.Add(this.rchTxtBx07);
            this.panel5.Controls.Add(this.rchTxtBx08);
            this.panel5.Controls.Add(this.rchTxtBx16);
            this.panel5.Controls.Add(this.rchTxtBx17);
            this.panel5.Controls.Add(this.rchTxtBx18);
            this.panel5.Controls.Add(this.rchTxtBx26);
            this.panel5.Controls.Add(this.rchTxtBx27);
            this.panel5.Controls.Add(this.rchTxtBx28);
            this.panel5.Location = new System.Drawing.Point(182, 19);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(88, 87);
            this.panel5.TabIndex = 9;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel4.Controls.Add(this.rchTxtBx03);
            this.panel4.Controls.Add(this.rchTxtBx04);
            this.panel4.Controls.Add(this.rchTxtBx05);
            this.panel4.Controls.Add(this.rchTxtBx13);
            this.panel4.Controls.Add(this.rchTxtBx14);
            this.panel4.Controls.Add(this.rchTxtBx15);
            this.panel4.Controls.Add(this.rchTxtBx23);
            this.panel4.Controls.Add(this.rchTxtBx24);
            this.panel4.Controls.Add(this.rchTxtBx25);
            this.panel4.Location = new System.Drawing.Point(94, 19);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(87, 87);
            this.panel4.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel2.Controls.Add(this.rchTxtBx30);
            this.panel2.Controls.Add(this.rchTxtBx31);
            this.panel2.Controls.Add(this.rchTxtBx32);
            this.panel2.Controls.Add(this.rchTxtBx40);
            this.panel2.Controls.Add(this.rchTxtBx41);
            this.panel2.Controls.Add(this.rchTxtBx42);
            this.panel2.Controls.Add(this.rchTxtBx50);
            this.panel2.Controls.Add(this.rchTxtBx51);
            this.panel2.Controls.Add(this.rchTxtBx52);
            this.panel2.Location = new System.Drawing.Point(6, 106);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(87, 87);
            this.panel2.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel3.Controls.Add(this.rchTxtBx60);
            this.panel3.Controls.Add(this.rchTxtBx61);
            this.panel3.Controls.Add(this.rchTxtBx62);
            this.panel3.Controls.Add(this.rchTxtBx70);
            this.panel3.Controls.Add(this.rchTxtBx71);
            this.panel3.Controls.Add(this.rchTxtBx72);
            this.panel3.Controls.Add(this.rchTxtBx80);
            this.panel3.Controls.Add(this.rchTxtBx82);
            this.panel3.Controls.Add(this.rchTxtBx81);
            this.panel3.Location = new System.Drawing.Point(6, 193);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(87, 87);
            this.panel3.TabIndex = 7;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel1.Controls.Add(this.rchTxtBx22);
            this.panel1.Controls.Add(this.rchTxtBx21);
            this.panel1.Controls.Add(this.rchTxtBx20);
            this.panel1.Controls.Add(this.rchTxtBx12);
            this.panel1.Controls.Add(this.rchTxtBx11);
            this.panel1.Controls.Add(this.rchTxtBx10);
            this.panel1.Controls.Add(this.rchTxtBx02);
            this.panel1.Controls.Add(this.rchTxtBx01);
            this.panel1.Controls.Add(this.rchTxtBx00);
            this.panel1.Location = new System.Drawing.Point(6, 19);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(87, 87);
            this.panel1.TabIndex = 5;
            // 
            // rchTxtBx22
            // 
            this.rchTxtBx22.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx22.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx22.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx22.Location = new System.Drawing.Point(59, 59);
            this.rchTxtBx22.Name = "rchTxtBx22";
            this.rchTxtBx22.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx22.TabIndex = 38;
            this.rchTxtBx22.Text = "";
            // 
            // rchTxtBx21
            // 
            this.rchTxtBx21.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx21.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx21.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx21.Location = new System.Drawing.Point(31, 59);
            this.rchTxtBx21.Name = "rchTxtBx21";
            this.rchTxtBx21.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx21.TabIndex = 37;
            this.rchTxtBx21.Text = "";
            // 
            // rchTxtBx20
            // 
            this.rchTxtBx20.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx20.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx20.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx20.Location = new System.Drawing.Point(3, 59);
            this.rchTxtBx20.Name = "rchTxtBx20";
            this.rchTxtBx20.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx20.TabIndex = 36;
            this.rchTxtBx20.Text = "";
            // 
            // rchTxtBx12
            // 
            this.rchTxtBx12.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx12.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx12.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx12.Location = new System.Drawing.Point(59, 31);
            this.rchTxtBx12.Name = "rchTxtBx12";
            this.rchTxtBx12.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx12.TabIndex = 35;
            this.rchTxtBx12.Text = "";
            // 
            // rchTxtBx11
            // 
            this.rchTxtBx11.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx11.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx11.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx11.Location = new System.Drawing.Point(31, 31);
            this.rchTxtBx11.Name = "rchTxtBx11";
            this.rchTxtBx11.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx11.TabIndex = 34;
            this.rchTxtBx11.Text = "";
            // 
            // rchTxtBx10
            // 
            this.rchTxtBx10.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx10.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx10.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx10.Location = new System.Drawing.Point(3, 31);
            this.rchTxtBx10.Name = "rchTxtBx10";
            this.rchTxtBx10.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx10.TabIndex = 33;
            this.rchTxtBx10.Text = "";
            // 
            // rchTxtBx02
            // 
            this.rchTxtBx02.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx02.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx02.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx02.Location = new System.Drawing.Point(59, 3);
            this.rchTxtBx02.Name = "rchTxtBx02";
            this.rchTxtBx02.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx02.TabIndex = 32;
            this.rchTxtBx02.Text = "";
            // 
            // rchTxtBx01
            // 
            this.rchTxtBx01.BackColor = System.Drawing.Color.LightBlue;
            this.rchTxtBx01.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx01.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx01.Location = new System.Drawing.Point(31, 3);
            this.rchTxtBx01.Name = "rchTxtBx01";
            this.rchTxtBx01.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx01.TabIndex = 31;
            this.rchTxtBx01.Text = "";
            // 
            // rchTxtBx00
            // 
            this.rchTxtBx00.BackColor = System.Drawing.Color.PowderBlue;
            this.rchTxtBx00.Font = new System.Drawing.Font("Modern No. 20", 11.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx00.ForeColor = System.Drawing.Color.DarkGreen;
            this.rchTxtBx00.Location = new System.Drawing.Point(3, 3);
            this.rchTxtBx00.MaxLength = 1;
            this.rchTxtBx00.Name = "rchTxtBx00";
            this.rchTxtBx00.ReadOnly = true;
            this.rchTxtBx00.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rchTxtBx00.Size = new System.Drawing.Size(25, 25);
            this.rchTxtBx00.TabIndex = 30;
            this.rchTxtBx00.Text = " ";
            this.rchTxtBx00.WordWrap = false;
            // 
            // btnSolve
            // 
            this.btnSolve.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSolve.BackColor = System.Drawing.Color.Silver;
            this.btnSolve.Enabled = false;
            this.btnSolve.ForeColor = System.Drawing.Color.Green;
            this.btnSolve.Location = new System.Drawing.Point(173, 41);
            this.btnSolve.Name = "btnSolve";
            this.btnSolve.Size = new System.Drawing.Size(77, 23);
            this.btnSolve.TabIndex = 4;
            this.btnSolve.Text = "Solve";
            this.btnSolve.UseVisualStyleBackColor = false;
            this.btnSolve.Click += new System.EventHandler(this.btnSolve_Click);
            // 
            // cmbBxPuzzles
            // 
            this.cmbBxPuzzles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBxPuzzles.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbBxPuzzles.FormattingEnabled = true;
            this.cmbBxPuzzles.Items.AddRange(new object[] {
            "Puzzle 1",
            "Puzzle 2",
            "Puzzle 3",
            "Puzzle 4",
            "Puzzle 5"});
            this.cmbBxPuzzles.Location = new System.Drawing.Point(115, 19);
            this.cmbBxPuzzles.Name = "cmbBxPuzzles";
            this.cmbBxPuzzles.Size = new System.Drawing.Size(135, 21);
            this.cmbBxPuzzles.TabIndex = 5;
            this.cmbBxPuzzles.SelectedIndexChanged += new System.EventHandler(this.cmbBxPuzzles_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(35, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Select Puzzle:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnSolve);
            this.groupBox1.Controls.Add(this.cmbBxPuzzles);
            this.groupBox1.Location = new System.Drawing.Point(11, 308);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(276, 74);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // FrmMain
            // 
            this.AcceptButton = this.btnExit;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(299, 434);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBxPuzzle);
            this.Controls.Add(this.btnExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sudoku Challenge";
            this.groupBxPuzzle.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.RichTextBox rchTxtBx03;
        private System.Windows.Forms.RichTextBox rchTxtBx04;
        private System.Windows.Forms.RichTextBox rchTxtBx05;
        private System.Windows.Forms.RichTextBox rchTxtBx06;
        private System.Windows.Forms.RichTextBox rchTxtBx07;
        private System.Windows.Forms.RichTextBox rchTxtBx08;
        private System.Windows.Forms.RichTextBox rchTxtBx13;
        private System.Windows.Forms.RichTextBox rchTxtBx14;
        private System.Windows.Forms.RichTextBox rchTxtBx15;
        private System.Windows.Forms.RichTextBox rchTxtBx16;
        private System.Windows.Forms.RichTextBox rchTxtBx17;
        private System.Windows.Forms.RichTextBox rchTxtBx18;
        private System.Windows.Forms.RichTextBox rchTxtBx23;
        private System.Windows.Forms.RichTextBox rchTxtBx24;
        private System.Windows.Forms.RichTextBox rchTxtBx25;
        private System.Windows.Forms.RichTextBox rchTxtBx26;
        private System.Windows.Forms.RichTextBox rchTxtBx27;
        private System.Windows.Forms.RichTextBox rchTxtBx28;
        private System.Windows.Forms.RichTextBox rchTxtBx30;
        private System.Windows.Forms.RichTextBox rchTxtBx31;
        private System.Windows.Forms.RichTextBox rchTxtBx32;
        private System.Windows.Forms.RichTextBox rchTxtBx33;
        private System.Windows.Forms.RichTextBox rchTxtBx34;
        private System.Windows.Forms.RichTextBox rchTxtBx35;
        private System.Windows.Forms.RichTextBox rchTxtBx36;
        private System.Windows.Forms.RichTextBox rchTxtBx37;
        private System.Windows.Forms.RichTextBox rchTxtBx38;
        private System.Windows.Forms.RichTextBox rchTxtBx40;
        private System.Windows.Forms.RichTextBox rchTxtBx41;
        private System.Windows.Forms.RichTextBox rchTxtBx42;
        private System.Windows.Forms.RichTextBox rchTxtBx43;
        private System.Windows.Forms.RichTextBox rchTxtBx44;
        private System.Windows.Forms.RichTextBox rchTxtBx45;
        private System.Windows.Forms.RichTextBox rchTxtBx46;
        private System.Windows.Forms.RichTextBox rchTxtBx47;
        private System.Windows.Forms.RichTextBox rchTxtBx48;
        private System.Windows.Forms.RichTextBox rchTxtBx50;
        private System.Windows.Forms.RichTextBox rchTxtBx51;
        private System.Windows.Forms.RichTextBox rchTxtBx52;
        private System.Windows.Forms.RichTextBox rchTxtBx53;
        private System.Windows.Forms.RichTextBox rchTxtBx54;
        private System.Windows.Forms.RichTextBox rchTxtBx55;
        private System.Windows.Forms.RichTextBox rchTxtBx56;
        private System.Windows.Forms.RichTextBox rchTxtBx57;
        private System.Windows.Forms.RichTextBox rchTxtBx58;
        private System.Windows.Forms.RichTextBox rchTxtBx60;
        private System.Windows.Forms.RichTextBox rchTxtBx61;
        private System.Windows.Forms.RichTextBox rchTxtBx62;
        private System.Windows.Forms.RichTextBox rchTxtBx63;
        private System.Windows.Forms.RichTextBox rchTxtBx64;
        private System.Windows.Forms.RichTextBox rchTxtBx65;
        private System.Windows.Forms.RichTextBox rchTxtBx66;
        private System.Windows.Forms.RichTextBox rchTxtBx67;
        private System.Windows.Forms.RichTextBox rchTxtBx68;
        private System.Windows.Forms.RichTextBox rchTxtBx70;
        private System.Windows.Forms.RichTextBox rchTxtBx71;
        private System.Windows.Forms.RichTextBox rchTxtBx72;
        private System.Windows.Forms.RichTextBox rchTxtBx73;
        private System.Windows.Forms.RichTextBox rchTxtBx74;
        private System.Windows.Forms.RichTextBox rchTxtBx75;
        private System.Windows.Forms.RichTextBox rchTxtBx76;
        private System.Windows.Forms.RichTextBox rchTxtBx77;
        private System.Windows.Forms.RichTextBox rchTxtBx78;
        private System.Windows.Forms.RichTextBox rchTxtBx80;
        private System.Windows.Forms.RichTextBox rchTxtBx81;
        private System.Windows.Forms.RichTextBox rchTxtBx82;
        private System.Windows.Forms.RichTextBox rchTxtBx83;
        private System.Windows.Forms.RichTextBox rchTxtBx84;
        private System.Windows.Forms.RichTextBox rchTxtBx85;
        private System.Windows.Forms.RichTextBox rchTxtBx86;
        private System.Windows.Forms.RichTextBox rchTxtBx87;
        private System.Windows.Forms.RichTextBox rchTxtBx88;
        private System.Windows.Forms.GroupBox groupBxPuzzle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox rchTxtBx22;
        private System.Windows.Forms.RichTextBox rchTxtBx21;
        private System.Windows.Forms.RichTextBox rchTxtBx20;
        private System.Windows.Forms.RichTextBox rchTxtBx12;
        private System.Windows.Forms.RichTextBox rchTxtBx11;
        private System.Windows.Forms.RichTextBox rchTxtBx10;
        private System.Windows.Forms.RichTextBox rchTxtBx02;
        private System.Windows.Forms.RichTextBox rchTxtBx01;
        private System.Windows.Forms.RichTextBox rchTxtBx00;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnSolve;
        private System.Windows.Forms.ComboBox cmbBxPuzzles;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

